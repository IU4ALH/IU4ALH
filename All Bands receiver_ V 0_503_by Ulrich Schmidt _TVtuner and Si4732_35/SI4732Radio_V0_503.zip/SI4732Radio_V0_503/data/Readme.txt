Please upload the files in this folder to the LittleFS. Either copy to SDcard, or via the LittleFS Uploader.
Change the CSV files as you please (for example frequencies and station names), but do not change the format.
