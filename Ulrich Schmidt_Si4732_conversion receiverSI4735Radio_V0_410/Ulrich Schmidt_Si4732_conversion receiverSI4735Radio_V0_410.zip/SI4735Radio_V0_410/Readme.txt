﻿Wideband receiver:

Here is the description of a wideband receiver project which covers 0.1-500 MHz. It is intended as an alternative to a SDR receiver. It fits in a small box and does not require
a PC or RPi for signal processing.
It uses ESP32, ILI9488 touch display, SI4732, SI5351 and AD831 as main components. A tinySA is used as optional panorama adapter. It uses potentiometers for volume, squelch and fine tune.
The software is a bit rough since I am not a programmer. It does include some nice features though, such as morse decoder, slow scan waterfall, memory bank scanning, web tools, etc.
To build the hardware you must have experience with RF circuits and the appropiate toolset. For building the filters you need a network analyzer or nanoVNA.
There is no schematics available, a lot of the hardware is based on try and error, but if you have experience with RF circuits you will be able to build it.

The double conversion receiver option is experimental only.It is intended for a first IF around 200MHz to reduce mirrors, but has proved difficult.



Brief hardware description of the single conversion receiver:

1.RF enters a  wideband LNA. It uses a MAR-6 + SBA-4089  2 stage LNA which  has about 30 dB of aplification. Important is to select a LNA that goes down to 0 MHz.
There is a similar commercial product available on Ebay and Aliexpress. MAR-6 is more robust and has a lower noise figure though.

2. FM input of SI4732 is connected via 30dB attenuator to the output of the LNA.

3. RF then enters the filter bank. The filters are crucial and the most difficult part of the project. The RF gets filtered by one of 6 filters:
0-30MHz lowpass = Filter 1, 25 - 65 bandpass = 2, 65 - 135 bandpass = 3, 116 - 148 steep bandpass = 4 , 148 - 220 = bandpass 5, above 220 highpass = 6
I used hand wound inductors and tuned them with a NanoVNA.This is not a good solution, there is not enough dampening for far off frequencies and losses are high.
Better would be to use smd inductors and a properly designed PCB. If you can't do that, use a veroboard, place input and output SMA connectors
close together, connect them with a thick ground wire and build the filter for the highest frequency closest to the connectors and the lowest frequencies furthest from the connectors.

Frequency ranges are described in struct FilterInfo and can be adjusted as needed. I had to adjust several, since the real life filter parameters
did not exactly meet the designed frequencies. The software activates the filter in use.
Filters are Chebyshev 5th order filters.
Filters were designed with an online filter tool and a ripple of 1db.  The selected filter gets connected to the output of the LNA and the input of the mixer
through two pin diodes (BAR64).
The pin diodes are placed as close to the SMA connectors as possible and connect to the repective filters via RG174 cables.
Current for each pin diode is about 5ma. For low frequencies you could also use 1N4148.
The 0-30 MHz low pass has two additional inductors from input and output (100uH) to ground to provide a DC path for the pin diodes. All other filters are ground shunted.
A 74LS138 3:8 decoder is connected to 3 GPIO's of the ESP32 and its outputs drive the bases of 6 PNP transistor through 680 Ohms resistors.
Their emitters are connected to +5V and the collectors drive the respective pair of pin diodes through 1K resistors.


4. The filtered RF then gets mixed down in an AD831 to the IF of 21.4MHz. I used the AD831 schematics from the application note with a 9V supply.
This is the only component that requires +9V supply. I also tried an ADE-1 diode ring mixer, but it required a much higher oscillator level, producing more spurs and interferences.
The AD 831 LO input is connected to two -6dB attenuators. One of them is connected directly to CLK2 of the SI5351 and is used for 0-200 MHz reception. The other one is connected
to CLK0 through a Chebyshev 7th order high pass. It supresses the fundamental and lets pass the 3rd harmonics which is used for 200-500MHz reception. This should better be a band pass,since it lets also pass the 5th harmonics
which still produces mirrors of digital television. If CLK0 is selected in software, the VFO gets programmed with 1/3 of its frequency.

CLK2 uses mainly high injection (LO above RF), but this can be configured in struct FilterInfo. If high injection produces too many mirrors, try low injection and viceversa.
This can be done in segments, so you can for example have too many mirrors in the 2m amateur band, define start and end frequencies in the structure and change injection mode.
CLK0 MHz uses mainly low injection (LO below RF). 500MHz RF is not the limit, I have tried up to 650MHz, but sensitivity drops rapidly.


6. The IF side of the AD831 is terminated with 50 Ohms and enters a crystal filter which is made of 3 cheap 21.4 MHz 2 pole crystal filters (Aliexpress) in series and ground inductors
in between. The input and output of the central crystal are connected to ground via 10 microhenry inductors.
The bandwith is +- 8 KHz, with around 70dB dampening at +- 15 KHz. There is a depression of around 2dB at the center frequency.
This filter unexpectedly allows excellent FM narrowband flank demodulation, so I did not build a seperate NBFM demodulator like originally planned. The ground capacitors were hand picked with a
nanoVNA. The filters flanks should not be too steep, otherwise FM demodulation will get distorted. It would even be better to use 2 separate filters, a narrow one for SSB and a wider one for AM/NBFM.
My filter's center frequency is off around 3KHz (21.397MHz) for some reason, but this can be compensated in software. The filter is critical for not overloading the SI4732.
The IF can be configured in the software, anything up to 30MHz is possible, so you can also use filters for different frequencies. The higher the IF, the better.

7. A tinySA is used as optional panorama adapter. Software connects it through micro relay to either the IF output of AD831 (through a 20dB attenuator), or to the output of the LNA via 6 dB attenuator.
   Please be aware that the tinySA has a quite limited resolution.

8. The crystal filter output connects to a SI4732. There is quite a loss (10 - 15 db estimated) through the crystal filter, since it does not use impendance transformers,
but the active mixer provides enough amplification to overcome it.
The SI4732 is controlled by an ESP32 development board. SI4732 is in the standard configuration with an external 32.768 KHz TCXO.The software for FM radio reception is quite basic.
One of the audio outputs go to a squelch transistor which is driven by the one of the ESP32 GPIO's. It grounds the audio signal when triggered and  eliminates noise and the hard cracks when switching mode.
From the squelch transistor the signal goes to the volume potentiomenter and then to a LM386 audioamplifier which drives headphones and speaker. GPIO26 is connected via 330KOhms
to the input of the audio amplifier and provides a short touch sound. The other audio output (pin 16) goes via a transistor amplifier to the sampling input of the ESP32 GPIO36, see (11).
For SSTV and experiments than need a frequency detector, an optional square wave shaper (2 transistor amplifier + NE555 Schmitt trigger) feed the audio square wave to GPIO39 of the ESP32.


9. The ESP32 drives the SI4732 and SI5351 on the same I2C bus. Bus speed is 2MHz, but will get autmatically reduced if the ESP32 can't initiate the SI4732.
A squelch potentiometer and a fine tune potentiometer are connected to the ESP32.
The fine tune potentiometer is also used to adjust color spectrum in waterfall mode. The fine tune pot needs to be of good quality, since any noise causes frequency jumps.
It is important to use a 38pin version of the ESP32 board since almost all of the GPIO's will be used.
The ESP32 also drives the 3.5" ILI9488 touch display in a standard configuration for the tft eSPI library.
This code will only work with ILI9488 480*320 pixel displays and is NOT adaptable for smaller displays.

10. 12V DC input input gets regulated through two linear regulators down to +5 and +9V. Power consumption is about 400ma.

11. For the FFT analysis and the morse decoder, audio output pin 16 goes via 4.7K and 1 microfarad to the base of a npn transistor amplifier. Emitter via 100 Ohms to ground, base via 47K to collector and collector via 1K to +3.3V.
Collector then goes to pin 36 of the ESP which does the sampling. Gain is about 20 dB.
Both applications require the master volume of the SI4732 to be set to a fixed level,
in this case around 50.

12. An additional audio amplifier with a square wave forming circuit consisting of a two transistor amplifier and optionally a NE555 can be connected to GPIO39.
This allows the experimental SSTV decoder to work.

13. If you use a tinySA, connect GPIO 1 of the ESP32 with the RX pin of the tinySA and GPIO 3 with the TX pin (close to the battery connector).
This will allow control of tinySA parameters from the receiver menu. Te tinySA can then be used in "RF" mode and will follow the tuned frequency.
If you do this, please note that the tinySA needs to be switched off when loading firmware into the ESP32.
Connect the tinySA audio output via 10K and 0.1uF in series to the audio output of the SI4732.
You can then listen to the tinySA. Check the Youtube video to see how it works.
Configure the TSA to use serial connection 115200 so that it accepts the commands from the ESP32. In "Preset" menu enable "Save Settings".
tinySA firmware version >= v1.4-105 2023-07-21 needed. This will control the TSA directly via serial commands.

14. Additional SD card support has been implemented. It uses the on board SD Card slot of the ILI9488 display. Connect the pins in parallel to the existing SPI bus, except the CS pin.
The SD Card CS pin gets connected to ESP32 GPIO 33. Not all SD cards work well.
It allows to update the 4 main structures (memory, filter frequencies, station scan frequencies and predefined bands) with values from the CSV files on the SD card,
so no recompiling is needed when values get changed. Also, the existing memory slots can be exported, edited (for example add names) and then re-imported.
It does require a formatted SPIFFS file system on the ESP32.
Do not introduce additional commas, CR or else anyting into the lines of the CSV files, there is little error checking implemented.


15. I have not designed a PCB, nor drawn full schematics. The ESP board is directly attached to the backside of the display. The HF part is build upon the copper sides of two seperate (unetched) PCB's with the SI4732, AD831, crystal filter and audio amp on one and the LNA and the filters on the other one.
SI5351 is placed in a metal box and connected through coax cables with the mixer.There is a shielding plate between the display and the RF boards. The I2C and SPI buses of the receiver and tinySA will cause some knocking noises on some frequencies, but with a clean built and proper shielding techniques these noises will mostly get buried in the atmospheric noise of the antenna.

16. To compile, the "No OTA (2MB APP, 2MB SPIFFS)" partition scheme needs to be selected. It should compile without errors or warning messages.



Software hints:

There is little error checking implemented, so if you press combinations that make no sense you will get a result that makes no sense.

Options to select a frequency: 1.Set Frequency manually via touchpad, 2. Load Memo, 3. Select a Band, or 4. Use Up- Down keys.
"Select Band": Loads a predefined band from struct BandInfo. Configurable, tuning either without limits (can leave the band) or loop mode (stays within band).
Scan: Seek up, Seek down, or set a range. Scan is squelch driven. If band loop mode is enabled, Seek will stay within the band.

TinySA: Touch indicator area (RF/IF) to select mode. In IF mode the IF spectrum will be displayed. Caveat: If Hi injection is enabled (default), the spectrum is mirrored.
In RF mode the tinySA is connected with the RF input. This mode is slower since the tinySA gets updated via serial commands. It has 2 submodes:

In track mode it syncs with the receiver and the tuned frequency is displayed in the center of the screen. This is slow.
In window mode, outside of a preselected band, a 1MHz window get displayed and marker 1 shows the tuned frequency. Tuning out of the window switches to the next window.
In window mode inside a preselected band, the entire band will be displayed and and marker 1 shows the tuned frequency.
In Config tinySA you can set parameters and also listen to the tinySA.
Buttons at the lower right area (right side of the miniwindow): R = reset tinySA. M1 = Drag marker 1 on the tinySA and the receiver will follow the tinySA. M2: Receiver will
tune to marker 2 (strongest signal in the window) M2F: Receiver will follow marker 2 (strongest signal in the window) as soon as the squelch gets closed.



SNRSquelch: Uses SNR to trigger audio mute and the squelch pot will not be used.This only works in AM mode.

Waterfall (slow scan): Touch on a spot on the lower horizontal signal bar (while it says "SCANNING") and enter listen mode.
Touch on the waterfall to go back to scan mode, or touch SET to set the frequency and leave.

Touch Tune: Shows 1MHz around tuned frequency, use encoder to change frequency. Touch a spot on the signal area and it tunes in and you can listen to frequency.
Use encoder to fine tune. Touch "Cont." to leave frequency and continue.Touch back to go back to main menu without setting the frequency. Touch "Set" to go back to main menu and set frequency.

2D/3D Waterfall displays a trapezoid that shows frequency time relationship and gives the illusion of a 3D waterfall.

After pressing the encoder,step size will be changed to 1MHz. This helps to rapidly view 1MHz segments on the tinySA. Press encoder again to return to previous step size.

Injection type: "Default Injection" uses the injection mode defined in the structure FilterInfo. High injection = permanent high side injection. Low injection = permanent low side injection.

Station scan: Will slowly scan through a list of (25) predefined stations. Can be configured to stop when audio or carrier is detected.


