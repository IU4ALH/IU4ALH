

The two folders - TFT_eSPI - BfButton - must be copied inside the Arduino Libraires folder ....
C: \ Users \ nameuser \ Documents \ Arduino \ libraries
replacing them, if any, with those present.
These have already been configured to use the 4-inch TFT display.
Good job !