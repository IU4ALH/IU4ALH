Please open the main file SI4732Radio_V0_501.ino for a description of this project.
