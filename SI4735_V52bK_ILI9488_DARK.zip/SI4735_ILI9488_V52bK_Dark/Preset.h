
//======================================================= Presets Groups    ================================
Group group[] PROGMEM = {
  733,    "MILANO",
  737,    "ROMA",
  762,    "FIRENZE",
  769,    "MODENA",
  771,    "VENEZIA",
  776,    "BOLOGNA",
  777,    "SALERNO",
  778,    "PADOVA",
};
//======================================================= END Presets Groups     ===========================

//======================================================= Memory     =======================================
Memory memory[] PROGMEM = {

  87.5,   "R. MARIA",           "777",  //
  87.9,   "R. RADICALE",        "777",  //
  88.2,   "R. CAPITAL",         "777",  //
  88.5,   "R. BUSSOLA 24",      "777",  //
  89.0,   "KISS KISS ITALIA",   "777",  //
  89.2,   "R. KISS KISS",       "777",  //
  89.6,   "R. IBIZA",           "777",  //
  90.0,   "RADIO VIRGIN",       "777",  //
  90.4,   "KISS KISS ITALIA",   "777",  //
  90.6,   "R. IBIZA",           "777",  //
  90.8,   "KISS KISS ITALIA",   "777",  //
  91.0,   "RADIO PUNTO NUOVO",  "777",  //
  91.3,   "RADIO MONTECARLO",   "777",  //
  91.5,   "RAI RADIO 1",        "777",  //
  91.7,   "RTL 102.5",          "777",  //
  92.0,   "R. KISS KISS",       "777",  //
  92.5,   "R. BALLABALLA",      "777",  //
  92.8,   "R. RCS 75",          "777",  //
  93.0,   "RAIGR PARLAMENTO",   "777",  //
  93.2,   "RAI RADIO 2",        "777",  //
  93.4,   "RADIO SPORTIVA",     "777",  //
  93.6,   "RADIO ROMANTICA",    "777",  //
  93.9,   "RADIO NORBA",        "777",  //
  94.2,   "RADIO MPA",          "777",  //
  94.5,   "KISS KISS NAPOLI",   "777",  //
  94.7,   "RADIO AMORE",        "777",  //
  94.9,   "RADIO ALFA",         "777",  //
  95.1,   "RAI RADIO 1",        "777",  // 
  95.4,   "RADIO SUBASIO",      "777",  // 
  95.6,   "RADIO 101",          "777",  //
  95.9,   "RADIO DEEJAY",       "777",  // 
  96.1,   "R. MARGHERITA",      "777",  // 
  96.4,   "R. DIMENSIONE SUONO","777",  // 
  96.6,   "RADIO NEWS 24",      "777",  // 
  97.0,   "RADIO FRECCIA",      "777",  // 
  97.4,   "RADIO RPZ",          "777",  // 
  97.7,   "M DUE O",            "777",  // 
  98.2,   "R. DIMENSIONE SUONO","777",  // 
  98.6,   "RAI RADIO 3",        "777",  // 
  98.9,   "RADIO 101",          "777",  // 
  99.1,   "RAI RADIO 3",        "777",  //
  99.4,   "RADIO SUBASIO",      "777",  // 
  99.7,   "RADIO BUSSOLA 24",   "777",  // 
  100.0,  "RADIO PUNTO NUOVO",  "777",  // 
  100.3,  "RADIO MARTE",        "777",  // 
  100.5,  "RADIO MARTE",        "777",  // 
  100.7,  "RADIO 105",          "777",  // 
  101.0,  "RADIO ZETA",         "777",  //
  101.3,  "RADIO DEEJAY",       "777",  // 
  101.6,  "RADIO 24",           "777",  // 
  101.8,  "RADIO IBIZA",        "777",  //
  102.0,  "RADIO ITALIA",       "777",  // 
  102.3,  "RADIO 101",          "777",  // 
  102.6,  "RADIO RTL 102.5",    "777",  // 
  102.8,  "RADIO CRC",          "777",  //   
  103.0,  "RADIO ALFA",         "777",  // 
  103.5,  "RADIO 24",           "777",  // 
  103.7,  "RADIO IBIZA",        "777",  // 
  104.0,  "RADIO 1 STATION",    "777",  //
  104.3,  "RADIO ITALIA",       "777",  //
  104.8,  "RADIO 105",          "777",  // 
  105.0,  "RADIO 105",          "777",  //
  105.5,  "RADIO MARIA",        "777",  // 
  105.7,  "RADIO AMORE",        "777",  //
  106.0,  "RADIO VIRGIN",       "777",  //
  106.3,  "RADIO BASE",         "777",  // 
  106.5,  "RADIO BUSSOLA 24",   "777",  // 
  106.9,  "RADIO ITALIA",       "777",  //
  107.2,  "R. DIMENSIONE SUONO","777",  //
  107.4,  "RADIO CAPITAL",      "777",  //
  107.7,  "RADIO MONTECARLO",   "777",  ///
 
  
   153,  "ROMANIA Actualitati", "ALL",  //
   162,  "FRANCIA Intern.",     "ALL",  //
   171,  "MAROCCO Medi 1",      "ALL",  //
   183,  "FRANCIA Europe 1",    "ALL",  //
   198,  "BBC Radio 4",         "ALL",  //
   207,  "Deutschland Radio",   "ALL",  //
   225,  "POLONIA Radio",       "ALL",  //
   234,  "RTL Luxenbourg",      "ALL",  //
   252,  "ALGERIA Chaine 3",    "ALL",  //
   270,  "CRO Czech.Repubbl.",  "ALL",  //


   576,  "Radio Vineyard Indonesia",     "777",  //
   603,  "Radio Utankayu",               "777",  //
   666,  "Radio Nam Nam Nam",            "777",  //
   693,  "Radio Muara",                  "777",  //
   702,  "Radio Tona",                   "777",  //
   720,  "Radio Silaturahim",            "777",  //
   756,  "Radio Rodja",                  "777",  //
   792,  "Radio Suara As Syafi'iyah",    "777",  //
   810,  "Buana Komunika",               "777",  //
   837,  "Radio Amoslem",                "777",  //
   936,  "Puspa Dwi Cipta Swara",        "777",  //
   954,  " Radio Benda Baru",            "777",  //
   999,  "RRI Jakarta",                  "777",  //
  1026,  "Suara Multazam",               "777",  //
  1062,  "Siaran Pusat Cendrawasih",     "777",  //
  1080,  "Suara Mega Asri Indonesia",    "777",  //
  1098,  "VOMS Untar",                   "777",  //
  1134,  "Radio Safari",                 "777",  //
  1224,  "Radio Metropolitan Jakarta",   "777",  //
  1332,  "Pro4 RRI Jakarta",             "777",  //
  1458,  "Ragesa Radio",                 "777",  //
  1494,  "Hana Citra Swara Jakarta",     "777",  //
   
  1521,  "BSKSA Arabia Saudita",     "777",  //
  1575,  "RAI Portofino (GE)",       "777",  //
  1584,  "R.StudioX Toscana",        "777",  //
  1602,  "R.Cartagena Spagna",       "777",  //

   
  7260,  "Asiatic Radio",       "ALL",  //
  27125,  "CB 14 Chan.",         "ALL",  //

};
