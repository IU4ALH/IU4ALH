28/03/2023


Updates: 

1. Change time from solar to legal depending on your country of 
   residence automatically. 
   See the sketch line 100
   "setting time zone, uncomment your preference"

2. Improved the weather function by entering the ID of your country,
   see the site openweathermap.org.

3. Now the SQUELH and BRIGHTNESS adjustments are separated.

4. To load the sketch set in TOOLS/Partition Scheme/"Huge APP (3MB No OTA/1MB SPIFFS)"